# churnerator
A collection of links to easily pause or cancel your subscription to various streaming services

[churnerator](https://churnerator.com/)

* Amazon Prime Video
* AppleTV+
* Disney+
* Hulu
* Max
* Netflix
* Paramount+

Please open an issue if there is streaming service cancel link you would like to suggest or let me know if any of the existing cancel link need to be update.
